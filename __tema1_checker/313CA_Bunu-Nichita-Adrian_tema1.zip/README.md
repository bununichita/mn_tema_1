# Copyright 2023 Nichita-Adrian Bunu <bununichita@gmail.com>
Doresc executia manuala a testelor in cazul in care sunt mai putin de 120p.



